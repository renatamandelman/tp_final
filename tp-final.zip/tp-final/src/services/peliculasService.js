import config from '../../dbconfig.js';
import sql from 'mssql';

class peliculasService{
    getAll = async () =>{
        try{
            const pool = await sql.connect(config);
            const result = await pool.request()
                .query("SELECT * FROM Pizzas");
            return result.recordset;
        }catch(error){
            console.log(error);
            
        }
    }


    
}