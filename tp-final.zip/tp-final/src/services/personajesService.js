import config from '../dbconfig.js';
import sql from 'mssql';

class personajesService{



    
}