import {Router} from 'express';
import peliculasService from '../../services/peliculasService';

const router=Router();
const PService=new peliculasService();